export interface ConnectionStatus {
    who: string;
    last: Date;
}



export interface Call {
    target: string;
    type: string;

}
